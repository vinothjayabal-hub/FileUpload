import { Component,Input,Output,EventEmitter } from '@angular/core';
import * as XLSX from 'xlsx';
import { HttpClient } from '@angular/common/http';
import { SheetJSComponent } from './sheet.component';

const { read, write, utils } = XLSX;
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'my-upload';
  name:string = '';
  age:number = 32;
  found:boolean = true;
  projectname:string = '';
  
  //@Input() Progress: SheetJSComponent.progress;
  constructor(private httpClient:HttpClient){ }
   info:any = this.getProfile();
   

  getProfile(){
    console.log("call");
    // console.log(this.Progress);
    // console.log(this.Progress.emit.length);
    // console.log(this.Progress.emit.name);
    this.httpClient.get(`http://localhost:5000`).subscribe(
      (data: any) => {
        this.projectname = data;
        console.log(data);
         // if(data.length){
            // this.age = data[0].age;
            // this.found = true;
         // }
      }
    )
  }
  
}
