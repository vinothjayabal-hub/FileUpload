import { Component, Input, Output, EventEmitter } from '@angular/core';
import { HttpClient, HttpRequest, HttpResponse, HttpEventType } from '@angular/common/http';
import { FileUploadService } from './file-upload.service';

import * as XLSX from 'xlsx';

type AOA = any[][];

@Component({
    selector: 'app-sheet',
    templateUrl: './sheet.component.html',
})

export class SheetJSComponent {
    //data: AOA = [[1, 2], [3, 4]];
    data: AOA = [];
    wopts: XLSX.WritingOptions = { bookType: 'xlsx', type: 'array' };
    fileName: string = 'SheetJS.xlsx';
    progress: number = 0;
    erroemsg: string = "";

    constructor(private httpClient: HttpClient, private readonly fileService: FileUploadService) { }


    onFileChange(evt: any) {
        /* wire up file reader */
        const target: DataTransfer = <DataTransfer>(evt.target);
        if (target.files.length !== 1) throw new Error('Cannot use multiple files');
        const reader: FileReader = new FileReader();
        console.log(evt.target.files);
        console.log(evt.target.files[0].name);
        let filetype: string = "";
        let filename: string = evt.target.files[0].name;
        var arr = filename.split(".");
        filetype = arr[1];
        if (filetype !== "xlsx" && filetype !== "csv") {
            // throw new Error('Select xlsx and csv file.');
            this.erroemsg = "Select xlsx/csv file.";
        }
        else {
            this.erroemsg="";
            reader.onload = (e: any) => {
                /* read workbook */
                const bstr: string = e.target.result;
                const wb: XLSX.WorkBook = XLSX.read(bstr, { type: 'binary' });

                /* grab first sheet */
                const wsname: string = wb.SheetNames[0];
                const ws: XLSX.WorkSheet = wb.Sheets[wsname];

                /* save data */
                this.data = <AOA>(XLSX.utils.sheet_to_json(ws, { header: 1 }));
                // this.postProfile(this.data);



                this.fileService.uploadAndProgress(evt)
                    .subscribe(event => {
                        if (event.type === HttpEventType.UploadProgress) {

                            this.progress = this.fileService.calcProgressPercent(event);

                        } else if (event instanceof HttpResponse) {

                            // the actual should be returned as something like
                            // this._control.setValue(event.body.url)        
                            //this._control.setValue('some url') 
                        }
                    });

            }

            this.data.map(res => {
                if (res[0] === "no") {
                    console.log(res[0]);
                } else {
                    console.log(res[0]);
                }
            })

        };


        reader.readAsBinaryString(target.files[0]);
    }



    submitfile() {
        console.log(this.data);
        this.httpClient.post(`http://localhost:5000/fileupload`, this.data).subscribe(
            (data: any) => {
                console.log("response data");
                console.log(data);
            }
        )
    }

    export(): void {
        /* generate worksheet */
        const ws: XLSX.WorkSheet = XLSX.utils.aoa_to_sheet(this.data);

        /* generate workbook and add the worksheet */
        const wb: XLSX.WorkBook = XLSX.utils.book_new();
        XLSX.utils.book_append_sheet(wb, ws, 'Sheet1');

        /* save to file */
        XLSX.writeFile(wb, this.fileName);
    }



}

